interface Interactable {
    public void interact();
}