interface Damageable {
    public void takeDamage(int damage);
}